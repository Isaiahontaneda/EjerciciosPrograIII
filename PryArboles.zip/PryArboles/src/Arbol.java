public class Arbol {
    private Nodo raiz;

    public Arbol(){
        raiz = null;
    }
    private void insertar(Nodo actual, Computador dato){
        if (dato.getCodigo() < actual.getComputador().getCodigo()){
            //izquierdo
            if (actual.getIzquierda()==null){ //libre
                actual.setIzquierda(new Nodo(dato));
            } else {
                //ocupado en lado izquierdo
                insertar(actual.getIzquierda(), dato);
            }
        } else {
            //derecho
            if (actual.getDerecha()==null){
                actual.setDerecha(new Nodo(dato));
            } else {
                insertar(actual.getDerecha(), dato);
            }
        }

    }
    public void insertar(Computador computador){
        if (raiz==null){
            raiz=new Nodo(computador);
        } else {
            insertar(raiz, computador); //recursivo
        }
    }
    private String inorden(Nodo actual){
       if (actual!=null){
           return inorden(actual.getIzquierda())+actual.getComputador()+inorden(actual.getDerecha());
       } else {
           return "";
       }
    }


    public String inorden(){
        if (raiz==null){
            return "No hay elementos en el arbol";
        } else {
            return inorden(raiz);
        }
    }
}
