import javax.swing.*;

public class Principal {
    public static void main(String[] args) throws Exception{
        Pila data=new Pila();
        try {
        data.push("Elemento 1");
        data.push("Elemento 2");
        data.push("Elemento 3");
        data.push("Elemento 4");
        data.push("Elemento 5");
        data.push("Elemento 6");
        data.push("Elemento 7");
        data.push("Elemento 8");
        data.push("Elemento 9");
        data.push("Elemento 10");
        data.push("Elemento 11");
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        System.out.println("Pila");
        System.out.println(data.toString());
        String eliminado= null;
        try {
            eliminado = data.pop();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        JOptionPane.showMessageDialog(null, eliminado);
        System.out.println("Pila");
        System.out.println(data.toString());
        JOptionPane.showMessageDialog(null,
                    "En la cima de la pila esta:"+data.cima());
    }
}
