import java.util.Stack;

public class Pila {
    private Stack<String> coleccion;

    public Pila(){
        coleccion=new Stack<String>(); //<> Se puede especificar un tipo de dato
    }
    public void push(String dato) throws Exception{
        if(coleccion.size()>=10)
            throw new Exception("Error: la pila alcanzó el límite de 10 elementos");
        coleccion.push(dato);
    }
    public String pop() throws Exception{

        if(coleccion.empty())
            throw new Exception("Error en método pop, pila vacia");
        return coleccion.pop();
    }
    public String cima() throws Exception{
        if(coleccion.empty())
            throw new Exception("Error en método cima, pila vacía");
        return coleccion.peek();
    }
    @Override
    public String toString(){

        StringBuilder listado=new StringBuilder();
        for(int i=coleccion.size()-1; i>=0; i--){
            listado.append(coleccion.get(i)+"\n");
        }

        return listado.toString();

    }

}
