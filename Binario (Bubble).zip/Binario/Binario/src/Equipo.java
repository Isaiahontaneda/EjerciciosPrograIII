import java.util.ArrayList;
import java.util.List;

public class Equipo {
    List<Jugador> lista;
    private int secuencia=0;

    public Equipo() {
        lista=new ArrayList<>();
    }

    public void agregarJugador(Jugador nuevo) throws Exception {
        // secuencia++;
        //nuevo.setCodigo(secuencia);
        for (Jugador j: lista) {
            if (j.getCodigo()==nuevo.getCodigo())
                throw new Exception("El codigo no es unico");
        }
        lista.add(nuevo);
        ordenar();

    }

    public void ordenar() {
        Jugador aux;
        int n = lista.size();

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (lista.get(j).getCodigo() > lista.get(j + 1).getCodigo()) {
                    aux = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, aux);
                }
            }
        }
    }

    public String listarTodos(){
        StringBuilder sb=new StringBuilder();
        for(Jugador j:lista){
            sb.append(j.toString());
        }
        return sb.toString();
    }

    public Jugador buscarJugador(int codigo) throws Exception{
        if(codigo<lista.getFirst().getCodigo() ||
                codigo>lista.getLast().getCodigo()){
            throw new Exception("Codigo no esta en la lista");
        }
        int inf=0;
        int sup=lista.size()-1;
        int cen;
        while(inf<=sup){
            cen=(inf+sup)/2;
            if(lista.get(cen).getCodigo()==codigo){
                return lista.get(cen);
            }else if(codigo<lista.get(cen).getCodigo()){
                sup=cen-1;
            }else{
                inf=cen+1;
            }
        }
        throw new Exception("El codigo no esta dentro de la lista");
    }
    public void editarJugador(int codigo, String nuevoNombre, float nuevoRendimiento, String nuevaPosicion) throws Exception {
        Jugador j = buscarJugador(codigo);
        j.setNombre(nuevoNombre);
        j.setRendimiento(nuevoRendimiento);
        j.setPosicion(nuevaPosicion);
    }

    public void eliminarJugador(int codigo) throws Exception {
        Jugador j = buscarJugador(codigo);
        lista.remove(j);
    }

}
